most possible
https://github.com/cbfield/terraform-aws-vpc

https://getbetterdevops.io/terraform-create-infrastructure-in-multiple-environments/